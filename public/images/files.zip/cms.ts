// ─────────────────────────────────────────────────────────
//  CMS. 케이스 스터디 내용은 전부 여기서 고친다.
//
//  구조
//    1. 타입          어떤 필드가 있는지
//    2. 케이스 4개     siftCaseV2 / fipetCaseV2 / lyftCaseV2 / biaslyCaseV2
//    3. 레지스트리     slug -> 케이스
//    4. 홈 목록 헬퍼   카드 정보는 각 케이스의 card 블록에서 나온다
//
//  고치는 법
//    - 카피, 수치, 이미지 경로, 링크: 해당 케이스 객체 안에서 바꾼다
//    - 굵게 표시할 구절: body.bold 배열에 원문 그대로 넣는다.
//      본문에 없는 문자열을 넣으면 조용히 무시된다
//    - 섹션을 빼고 싶으면 필드를 통째로 지운다.
//      beforeAfter / evidence / solution2 / exploration / underHood /
//      research 는 선택 사항이라 없으면 코드가 알아서 건너뛴다
//    - 새 케이스: 객체 하나 더 만들고 casesV2 에 slug 를 등록한다
// ─────────────────────────────────────────────────────────

export type V2Body = {
  text: string
  bold?: string[]          // 잉크 볼드로 강조할 구절 (본문 회색 위)
}

export type V2Result = {
  value: number
  decimals?: number
  suffix?: string
  label: string            // mono 소라벨
  desc: string
  hot?: boolean            // true = 코발트
}

export type V2BentoData = {
  a: {
    tag: string            // "ON THE TICKET"
    level: string          // "Low confidence"
    pct: string            // "41%"
    sentence: string
    whyTag: string         // "WHY THIS IS UNCERTAIN"
    rows: [string, string][]   // [라벨, 모노값]
  }
  b: {
    tag: string
    title: string
    pills: { label: string; active: boolean }[]
    sliderPct: number      // 0–100
    note: string
  }
  c: {
    tag: string
    ticketTitle: string
    ticketMeta: string
    lockLabel: string
    rightTitle: string
    rightSub: string
    caption: string
  }
}

export type V2Persona = {
  label: string
  name: string
  meta: string
  quote: string
  needs: string[]
  implication: string
}

/* 저니. 화면 목록이 아니라 신뢰가 깨지는 순간의 목록이다. */
export type V2Moment = {
  phase: string
  question: string
  surface: string
  breaks: string
}

/* 이미지 위 변경점 표식. x, y 는 이미지 좌상단 기준 % 이고 눈으로 맞추는 값이다. */
export type V2Hotspot = {
  x: string
  y: string
  title: string
  body: string
}

/* 3안 비교. 스크린샷 대신 코드로 그린다.
   모바일 화면을 3:2 로 자르면 정보가 잘려서 차이가 안 보인다.
   보여줘야 할 건 화면이 아니라 세 안의 차이다. */
export type V2Alternative = {
  verdict: '✗' | '✓'
  title: string
  what: string     // 이 안이 무엇인가, 한 줄
  why: string      // 왜 떨어졌나 / 왜 남았나
}

export type V2FlowCard = {
  title: string
  sub: string
  tone: 'cobalt' | 'amber' | 'red'
}

export type V2DotRound = {
  label: string
  n: number
  avg: number
  data: Record<number, number>   // {점수: 인원}
}

/* 홈 목록 카드에 쓰는 정보. 케이스 본문과 한 곳에서 관리한다. */
export type CaseCard = {
  slug: string
  title: string
  description: string
  year: string
  /* 제목 옆 아웃라인 태그. 두 개까지. 연도는 코드가 마지막 태그로 붙인다. */
  tags: string[]
  category: string        // 레거시. tags 로 교체 중
  featured: boolean
  order: number
  coverImage: string
  thumbBg: string
}

export type CaseV2 = {
  card: CaseCard
  meta: string
  h1: [string, string]           // 두 줄
  heroImage: string
  heroAlt: string
  heroOverlays?: {
    src: string
    alt?: string
    left: string        // 히어로 이미지 기준 %
    top: string
    width: string       // height 는 자동, PNG 원본 비율 유지
  }[]
  roleMeta: { label: string; value: string }[]

  statCard: { text: string; bold: string }

  overview: { label: string; body: V2Body; linkLabel: string; linkHref: string }

  outcome: { label: string; body: V2Body; results: V2Result[] }

  persona: V2Persona
  journey: { label: string; statement: string; body: V2Body; moments: V2Moment[] }

  beforeAfter?: {
    r1Image: string; r2Image: string
    r1Alt: string; r2Alt: string
    r1Chip: string; r2Chip: string
    hint: string
    r1Hotspots: V2Hotspot[]
    r2Hotspots: V2Hotspot[]
  }

  evidence?: {
    label: string; statement: string; body: V2Body
    rounds?: V2DotRound[]
    axisNote?: string
    pauseMs?: number
  }

  solution1: { label: string; statement: string; body: V2Body; bento: V2BentoData }
  solution2?: { label: string; statement: string; body: V2Body; image: string; imageAlt: string }

  exploration?: {
    label: string; statement: string; body: V2Body
    alternatives: V2Alternative[]
    flowIntro?: { title: string; chips: string }
    flowCards?: V2FlowCard[]
    flowNote?: string
  }

  underHood?: {
    label: string; statement: string; body: V2Body
    specs: { v: string; l: string; hot?: boolean }[]
    linkLabel: string; linkHref: string
    demo?: 'sift-model'          // 라이브 데모 위젯을 붙일 케이스에만
  }

  quote?: { text: string; attribution: string }   // 페이지에서 더 이상 쓰지 않음

  research?: { label: string; statement: string; body: V2Body }

  fullStory: {
    heading: string
    paragraphs: { title: string; body: V2Body }[]
  }

  reflections: { num: string; title: string; body: string }[]

  footer: { copyright: string; links: { label: string; href: string }[] }
}

// ── V2 content ────────────────────────────────────────
export const siftCaseV2: CaseV2 = {
  card: {
    slug: 'triage',
    tags: ['Product design', 'Machine learning'],
    title: 'Sift · AI ticket triage',
    description: 'AI ticket tools compete on how much they can automate. Agents don’t need more automation, they need to see what the AI did, why, and how to take it back.',
    year: '2026',
    category: 'Concept · B2B SaaS',
    featured: true,
    order: 1,
    coverImage: '/images/triage-cover.webp',
    thumbBg: '#101a3a',
  },
  meta: 'Jun – Jul 2026 · Self-directed concept',
  h1: ['When the AI files it,', 'someone answers for it'],
  heroImage: '/images/sift-hero-inbox.png',
  heroAlt: 'Sift inbox, AI-sorted queue with confidence, category and undo',

  // 배경·그림자·토스트·툴팁이 전부 heroImage PNG 안에 구워져 있으므로 비워 둔다.
  // 여기에 뭔가 넣으면 히어로 위에 그대로 얹힌다. 파일이 없으면 깨진 이미지가 뜬다.
  heroOverlays: [],

  roleMeta: [
    { label: 'Role',  value: 'Solo designer, end to end' },
    { label: 'Scope', value: 'Product design, research, model training, prototyping' },
    { label: 'Tools', value: 'Figma, FigJam, Maze' },
  ],

  statCard: {
    text: '83.5% of support professionals clicked everywhere except the control that decides how much the AI does.',
    bold: '83.5% of support professionals',
  },

  overview: {
    label: 'Overview',
    body: {
      text: 'AI ticket tools compete on how much they can automate. Agents don’t need more automation. They need to see what the AI did, why, and how to take it back. I designed Sift end to end, tested it in two rounds with twelve working CX professionals, and fine-tuned the classification model myself.',
      bold: ['see what the AI did, why, and how to take it back', 'fine-tuned the classification model myself'],
    },
    linkLabel: 'Open the prototype',
    linkHref: 'https://www.figma.com/proto/WnhBcVjCxsqABf2mBbvPXf/Ticket-Triage-%E2%80%94-Early-Exploration?node-id=206-2&p=f&viewport=241%2C97%2C0.12&t=qmneUfYqf8vRVwBQ-1&scaling=min-zoom&content-scaling=fixed&starting-point-node-id=206%3A2&show-proto-sidebar=1&page-id=64%3A2',
  },

  outcome: {
    label: 'Outcome',
    body: {
      text: 'Two rounds of usability testing, a redesign between them, and a working model underneath. The design shipped as 21 wired screens with a live in-browser demo. Not a mockup of intelligence, but the thing itself.',
      bold: ['21 wired screens with a live in-browser demo', 'not a mockup of intelligence, but the thing itself'],
    },
    results: [
      { value: 0, suffix: '%', label: 'misclick rate', hot: true,
        desc: 'Down from 83.5% on the critical task. Same mission, same population, one redesign in between.' },
      { value: 4.4, decimals: 1, suffix: '/5', label: 'perceived control',
        desc: 'Up from 3.0. Twelve working CX professionals, two rounds, identical task blocks.' },
      { value: 99.67, decimals: 2, suffix: '%', label: 'model intent accuracy',
        desc: 'A classifier I fine-tuned myself, calibrated to ECE 0.0016 and running client-side.' },
    ],
  },

  persona: {
    label: 'Who it is for',
    name: 'Maya Chen',
    meta: 'Support agent · 142 open tickets today',
    quote: '“If it files something wrong, I’m the one who hears about it.”',
    needs: [
      'See why the AI chose, not only what it chose',
      'Take back any automated action in one tap',
      'Decide how much the AI does, category by category',
    ],
    implication: 'One persona, deliberately. Team leads set policy and read audit trails, and scoping them out is what let the agent seat go deep instead of wide.',
  },

  journey: {
    label: 'Journey',
    statement: 'Trust does not break in general. It breaks at three moments.',
    body: {
      text: 'Most tools design the middle moment and leave the other two to chance. Mapping all three is why this needed 21 screens instead of a dashboard and an inbox.',
      bold: ['design the middle moment and leave the other two to chance'],
    },
    moments: [
      {
        phase: 'Before the AI acts',
        question: 'What will it do with this?',
        surface: 'Settings, per-category thresholds',
        breaks: 'Without a visible dial, trust never forms. What looks like trust is only hope.',
      },
      {
        phase: 'While the AI acts',
        question: 'What is it doing right now?',
        surface: 'Status banner, loading state, dashboard',
        breaks: 'Silence reads as concealment. Progress has to be real, not a spinner.',
      },
      {
        phase: 'After the AI acts',
        question: 'What did it do, and can I take it back?',
        surface: 'Activity log, undo toast, reasoning card',
        breaks: 'This is where the major tools are thinnest, and where accountability lands hardest.',
      },
    ],
  },

  beforeAfter: {
    r1Image: '/images/sift-ba-r1-settings.png',
    r2Image: '/images/sift-ba-r2-inbox.png',
    r1Alt: 'Round 1: the only control, buried in Settings',
    r2Alt: 'Round 2: automation controls surfaced as four doors in the inbox',
    r1Chip: 'Round 1 · one entry, buried in Settings',
    r2Chip: 'Round 2 · four doors, in the flow',
    hint: 'Same mission, same population, one redesign apart. Hover a marker to see what moved.',

    r1Hotspots: [
      { x: '48%', y: '52%',
        title: 'The only way in',
        body: 'Round 1 shipped one entry to the automation control, inside Settings. 83.5% of participants misclicked looking for it, and one searched thirteen screens for five minutes before giving up.' },
    ],

    r2Hotspots: [
      { x: '90%', y: '11%',
        title: 'AI assist toggle',
        body: 'The heatmap showed people clicking here first in Round 1, where nothing happened. In Round 2 it opens the control, and it became the busiest door.' },
      { x: '18%', y: '25%',
        title: 'Auto-triage status card',
        body: 'The banner reports what the AI did today. Making the report itself clickable turned a status line into an entry point.' },
      { x: '76%', y: '25%',
        title: 'Adjust automation',
        body: 'A named link in the flow, not a settings icon. People who wanted the dial no longer had to guess where it lived.' },
      { x: '58%', y: '48%',
        title: 'Confidence cell',
        body: 'The threshold line on a ticket is where the number gets questioned, so the control opens from there too.' },
    ],
  },

  evidence: {
    label: 'Evidence',
    statement: 'Averages hide fights. Distributions show them.',
    body: {
      text: 'Round 1’s average of 3.0 looked unremarkable. The distribution wasn’t: a cluster at 4 and a cluster at 1 to 2, split by whether people ever found the control. Round 2 asked the same question of the same population. Every participant answered 4 or 5.',
      bold: ['a cluster at 4 and a cluster at 1 to 2', 'every participant answered 4 or 5'],
    },
    rounds: [
      { label: 'Round 1', n: 7, avg: 3.0, data: { 1: 1, 2: 2, 4: 4 } },
      { label: 'Round 2', n: 5, avg: 4.4, data: { 4: 3, 5: 2 } },
    ],
    axisNote: 'Felt sense of control · 1 = none → 5 = full',
    pauseMs: 600,
  },

  solution1: {
    label: 'Solution 01',
    statement: 'Confidence, written as a sentence people can calibrate',
    body: {
      text: 'Raw percentages lie to the gut. Every number carries a frequency line, right about 41 of 100 on tickets like this, and it appears in all three places the agent meets the AI.',
      bold: ['right about 41 of 100', 'all three places'],
    },
    bento: {
      a: {
        tag: 'On the ticket',
        level: 'Low confidence',
        pct: '41%',
        sentence: 'On tickets like this, the AI has been right about 41 of 100.',
        whyTag: 'Why this is uncertain',
        rows: [
          ['Matched', 'refund · order reference'],
          ['Signal', 'billing dispute, 0.41'],
          ['Lowered by', 'overlap with account access'],
        ],
      },
      b: {
        tag: 'In settings',
        title: 'Confidence threshold',
        pills: [
          { label: 'Conservative · 90%', active: false },
          { label: 'Balanced · 85%', active: true },
          { label: 'Aggressive · 70%', active: false },
        ],
        sliderPct: 75,
        note: 'At 85%, the AI has been right about 96 of every 100 similar tickets.',
      },
      c: {
        tag: 'In the queue',
        ticketTitle: 'Delete my account and all data',
        ticketMeta: '#48196 · Tom Kim · 11m',
        lockLabel: 'Always human',
        rightTitle: 'Not scored',
        rightSub: 'the AI did not judge this',
        caption: 'Risk policy visible where the work happens.',
      },
    },
  },

  solution2: {
    label: 'Solution 02',
    statement: 'A dial the agent owns, and friction only where it earns its cost',
    body: {
      text: 'How much the AI does is a setting, not a policy handed down. One threshold per category, because a bug report and an account deletion are not the same risk. Account deletion stays Always human, permanently.',
      bold: ['a setting, not a policy', 'Always human, permanently'],
    },
    image: '/images/sift-friction-confirm.png',
    imageAlt: 'Glass confirmation: friction only for expensive mistakes',
  },

  exploration: {
    label: 'Exploration',
    statement: 'Three architectures. One survived.',
    body: {
      text: 'Review everything and the queue becomes rubber-stamping. Automate everything and trust never forms. The survivor routes by confidence, and by risk.',
      bold: ['routes by confidence', 'and by risk'],
    },
    alternatives: [
      {
        verdict: '✗',
        title: 'Review everything',
        what: 'Every AI suggestion lands in an approval queue. Nothing moves until a human confirms it.',
        why: 'At 142 tickets a day, approval becomes rubber-stamping. That is overreliance wearing a safety costume, and it throws away the volume relief that justifies AI triage.',
      },
      {
        verdict: '✗',
        title: 'Automate everything, undo after',
        what: 'The AI files every ticket on its own. The agent gets a complete activity log and a global undo.',
        why: 'When everything is automatic, review atrophies. An auto-processed account deletion is not an undo story, it is an incident.',
      },
      {
        verdict: '✓',
        title: 'Confidence-routed, per category',
        what: 'Auto-sort above a threshold the agent sets per category, route everything below it to a person, never touch locked categories.',
        why: 'The only architecture where speed and judgment coexist. At threshold 100 it degrades into option 01, so a cautious team can start there and move.',
      },
    ],
    flowIntro: { title: 'Every incoming ticket gets a proposal', chips: 'category · priority · confidence' },
    flowCards: [
      { title: 'Above threshold', sub: 'Auto-sorted · undo stays open', tone: 'cobalt' },
      { title: 'Below threshold', sub: 'Needs review · routed to a human first', tone: 'amber' },
      { title: 'Sensitive category', sub: 'Always human · never auto, permanently', tone: 'red' },
    ],
    flowNote: 'one dial per category · every automated action reversible',
  },

  underHood: {
    label: 'Under the hood',
    statement: 'The model is real, and it runs in the browser',
    body: {
      text: 'Rather than mock the intelligence, I built it: a DistilBERT classifier fine-tuned on 24,370 support tickets, calibrated to ECE 0.0016, quantized to 68 MB and deployed with transformers.js. Every confidence number in the design comes from a model that actually produces it, and nothing you type leaves the page.',
      bold: ['I built it', 'calibrated to ECE 0.0016', 'nothing you type leaves the page'],
    },
    specs: [
      { v: '24,370', l: 'tickets fine-tuned on' },
      { v: '99.67%', l: 'intent accuracy' },
      { v: '0.0016', l: 'expected calibration error', hot: true },
      { v: '68 MB', l: 'quantized, in-browser' },
    ],
    demo: 'sift-model',
    linkLabel: 'Model card on Hugging Face',
    linkHref: 'https://huggingface.co/heart8693/sift-intent-classifier',
  },

  quote: {
    text: '“If it files something wrong, I’m the one who hears about it.”',
    attribution: 'the agent this was designed for',
  },

  research: {
    label: 'Research',
    statement: 'Even at 95%, experts still read the ticket',
    body: {
      text: 'Four stimuli, one identical ticket, only the stated confidence varied. Three of five professionals checked the source before accepting at 95%. That isn’t distrust. It’s their name on the decision. So the design stopped asking for trust and started making verifying fast.',
      bold: ['Three of five professionals checked the source', 'making verifying fast'],
    },
  },

  fullStory: {
    heading: 'The full story',
    paragraphs: [
      {
        title: 'How the evidence was graded',
        body: {
          text: 'Concept projects invite cherry-picking, so I graded every source before it could influence a decision. Verified meant peer-reviewed or replicated. Directional meant a single credible study. Vendor claim meant marketing numbers, treated only as a signal of what companies believe. The grading changed the design: frequency framing rests on Verified research and shipped as a core pattern, while the feedback-framing decision rested on a Directional finding and shipped as a hypothesis Round 1 was built to check.',
          bold: ['The grading changed the design'],
        },
      },
      {
        title: 'What testing settled, and what it did not',
        body: {
          text: 'Both rounds ran unmoderated in Maze on the wired prototype, blocks 1 to 10 identical word for word. Five CX participants per round is enough to expose a broken flow and not enough to estimate an effect size, so 83.5% to 0% is a before-and-after of one redesign, not a controlled experiment. With no production data, the model’s calibration outside my held-out set is untested. Round 3 has a scope: badge affordance on the chips, a copy test on Adjust automation, and one open response suggesting the human-in-the-loop philosophy could be more legible on the surface.',
          bold: ['not a controlled experiment', 'Round 3 has a scope'],
        },
      },
    ],
  },

  reflections: [
    { num: '01', title: 'Failing in front of seven people',
      body: 'Round 1 broke publicly on my own site. Nobody made me run it, and rebuilding after it is the part of this project I would defend hardest.' },
    { num: '02', title: 'Honesty is a set of decisions that don’t demo',
      body: 'A frequency sentence, a Not scored label, an error banner whose first message is that the human can keep working. Each one is skippable and none of them show up in a demo.' },
  ],

  footer: {
    copyright: '© 2026 Dean Yoo',
    links: [
      { label: 'Email', href: 'mailto:hyart2021@gmail.com' },
      { label: 'LinkedIn', href: 'https://linkedin.com/in/dean-yoo' },
      { label: 'Resume', href: '/resume' },
    ],
  },
}
// ═══════════════════════════════════════════════════════
//  cms.ts 맨 아래에 붙여넣기.
//  siftCaseV2 와 같은 CaseV2 타입을 쓴다. 새 타입 없음.
//  모든 수치와 인용은 기존 projects[] 데이터에서 가져온 것이고
//  새로 지어낸 사실은 없다.
// ═══════════════════════════════════════════════════════

export const fipetCaseV2: CaseV2 = {
  card: {
    slug: 'fipet',
    tags: ['Product design', 'Design systems'],
    title: 'FiPet',
    description: 'FiPet shipped to the App Store without a single usability test. I led the redesign around a new 1v1 Quiz Battle feature and ran the company’s first usability test.',
    year: '2026',
    category: 'Internship · Mobile',
    featured: true,
    order: 2,
    coverImage: '/images/fipet-cover.webp',
    thumbBg: '#2d1810',
  },
  meta: 'Mar – May 2026 · Internship',
  h1: ['They shipped to the App Store', 'without testing it once'],
  heroImage: '/images/fipet-hero-v2.webp',
  heroAlt: 'FiPet 1v1 Quiz Battle, home screen and battle loop',
  heroOverlays: [],

  roleMeta: [
    { label: 'Role',  value: 'Product design intern, lead on Quiz Battle' },
    { label: 'Team',  value: '1 PM, 2 designers, 10 engineers' },
    { label: 'Tools', value: 'Figma, Maze, React' },
  ],

  statCard: {
    text: '10 of 10 interview participants called the app overwhelming. One said it felt like homework, which is the exact word a financial literacy app for kids cannot afford.',
    bold: '10 of 10 interview participants',
  },

  overview: {
    label: 'Overview',
    body: {
      text: 'FiPet launched with no usability testing, few downloads, and reviews that repeated the same complaints. I led design for a new 1v1 Quiz Battle feature, built the design system the rest of the team adopted, and ran the first usability test in the company’s history.',
      bold: ['no usability testing', 'the first usability test in the company’s history'],
    },
    linkLabel: 'Open the coded prototype',
    linkHref: 'https://fipet-quiz-battle.vercel.app/',
  },

  outcome: {
    label: 'Outcome',
    body: {
      text: 'Thirty screens, a design system adopted beyond my feature, and a testing practice the team kept. The numbers below come from Round 1, the company’s first test.',
      bold: ['a design system adopted beyond my feature', 'the company’s first test'],
    },
    results: [
      { value: 90, suffix: '%', label: 'would play again', hot: true,
        desc: '9 of 10 full completions. This is the number that settled the Play Again versus Buy with coins argument.' },
      { value: 4.2, decimals: 1, suffix: '/5', label: 'fun rating',
        desc: 'The first measurable engagement signal in the product’s history.' },
      { value: 100, suffix: '%', label: 'task success',
        desc: 'Per task block, across 22 recorded sessions on the core flow.' },
    ],
  },

  persona: {
    label: 'Who it is for',
    name: 'Kids, ages 8 to 15',
    meta: 'First-time users · intercepted in public spaces',
    quote: '“It’s so confusing. I don’t even know what this app is for.”',
    needs: [
      'Something to tap within the first ten seconds',
      'A clear signal that this is not homework',
      'One consistent visual language, not five',
    ],
    implication: 'Parents are the second audience and the decision-makers, but the failure happened before they mattered. Kids opened the app once, could not tell what to do, and never came back.',
  },

  journey: {
    label: 'Journey',
    statement: 'Kids dropped off before the lesson, not during it.',
    body: {
      text: 'My first instinct was to redesign the lessons. The interviews pointed somewhere else: most kids never got far enough to be bored by the curriculum. The intervention point was the home screen and whether it answered why anyone should open the app on day two.',
      bold: ['most kids never got far enough to be bored by the curriculum'],
    },
    moments: [
      {
        phase: 'First open',
        question: 'What is this app for?',
        surface: 'Home screen',
        breaks: 'The original opened to a lesson list, the default of a product built around content rather than a reason to return.',
      },
      {
        phase: 'First interaction',
        question: 'Is this going to be fun or is it school?',
        surface: 'Quick Battle card, 60-second match',
        breaks: 'Learning has to happen inside play. Put it before play and the app becomes an assignment.',
      },
      {
        phase: 'Right after winning',
        question: 'What do I do now?',
        surface: 'Result screen',
        breaks: 'This is the emotional peak. Send a kid to a shop here and the loop the game just built collapses.',
      },
    ],
  },

  evidence: {
    label: 'Evidence',
    statement: 'The first task failed before anyone reached the game.',
    body: {
      text: 'Round 1 logged 22 recorded sessions. Task success was 100%, which looked fine until the misclick rate came in at 65.9% on the first task. One participant explained it plainly: the Start button sat below the fold, so they read the page as a buffer screen. Average duration was 228 seconds for what should have been an obvious entry point.',
      bold: ['65.9% on the first task', 'the Start button sat below the fold'],
    },
  },

  research: {
    label: 'Research',
    statement: 'Naming a feature 1v1 is not enough if it plays solo.',
    body: {
      text: 'When asked what they liked most, only 20% chose competing against a rival, the lowest of three options. Participants wanted to see what the rival answered, not just a score at the end. The fix was to show the rival’s answer on the reveal screen and add a waiting state during their turn, so the competition is visible while it happens rather than summarised afterward.',
      bold: ['only 20% chose competing against a rival'],
    },
  },

  solution1: {
    label: 'Solution 01',
    statement: 'Play Again, not Buy with earned coins',
    body: {
      text: 'The PM wanted the shop as the primary action on the result screen. Users had just earned coins, and conversion would never be higher. I argued the opposite, and the disagreement was about who the user actually is.',
      bold: ['The PM wanted the shop as the primary action'],
    },
    bento: {
      a: {
        tag: 'The argument',
        level: 'Momentum, not transaction',
        pct: '8 to 15',
        sentence: 'Kids this age are momentum-driven. The moment after winning is an emotional high, and a shop interrupts the loop the game just built.',
        whyTag: 'What the position rested on',
        rows: [
          ['Verified', 'Flow Theory, Csikszentmihalyi 1990'],
          ['Verified', 'children more flow-sensitive, PMC 2020'],
          ['Directional', '78% of parents, Commonwealth Bank 2023'],
        ],
      },
      b: {
        tag: 'What shipped',
        title: 'Play Again as primary, shop reachable from home',
        pills: [
          { label: 'Play Again · primary', active: true },
          { label: 'Home · secondary', active: false },
          { label: 'Shop · from home', active: false },
        ],
        sliderPct: 90,
        note: 'Round 1 later validated the call: 90% said they would play again.',
      },
      c: {
        tag: 'Why it landed',
        ticketTitle: 'Specificity, not preference',
        ticketMeta: 'three citations, not one opinion',
        lockLabel: 'Agreed and shipped',
        rightTitle: 'Revisit post-launch',
        rightSub: 'with real engagement data',
        caption: 'The PM had a defensible position, so mine had to be more defensible.',
      },
    },
  },

  solution2: {
    label: 'Solution 02',
    statement: 'A system four decisions wide, so the team could actually use it',
    body: {
      text: 'One orange accent on a flat cream background, Inter throughout, SVG line icons, an 8pt grid. I scoped it small on purpose. The rest of the team adopted it for the broader redesign, which is the only measure of a design system that matters.',
      bold: ['I scoped it small on purpose', 'the only measure of a design system that matters'],
    },
    image: '/images/fipet-system-v2.webp',
    imageAlt: 'FiPet design system, one accent color, Inter, SVG line icons, 8pt grid',
  },

  exploration: {
    label: 'Exploration',
    statement: 'Three home screens. Only one gave a reason to come back.',
    body: {
      text: 'The feature was already chosen in a company-wide meeting. What was open was the experience around it, and that is where the home screen decided everything downstream.',
      bold: ['the experience around it'],
    },
    alternatives: [
      {
        verdict: '✗',
        title: 'Daily lesson with streak',
        what: 'A Duolingo-style daily lesson with a visible streak counter on the home screen.',
        why: 'Familiar and cheap to ship, but still solo. A streak asks for self-discipline, which is not an 8 to 15 year old strength, and it gives no reason to open the app beyond obligation.',
      },
      {
        verdict: '✗',
        title: 'Social feed of friend activity',
        what: 'A feed showing what friends are learning and earning: badges, streaks, level-ups.',
        why: 'Social but passive, with no clear action to take. Concept testers said it looked like another Instagram, and a sparse network makes it weakest exactly at launch.',
      },
      {
        verdict: '✓',
        title: '1v1 Quiz Battle',
        what: 'Sixty-second matches against a friend, with pending matches and invites leading the home screen.',
        why: 'The only direction that is active, social, and time-bound at once. It was also the most expensive to build, which raised the bar for choosing it rather than lowering it.',
      },
    ],
  },

  underHood: {
    label: 'Under the hood',
    statement: 'Some questions a static prototype cannot answer',
    body: {
      text: 'After Round 1 the obvious next step was another Figma iteration. I argued against it. Real timer pressure, live score updates, rival turn-taking, and answer-switching mid-question cannot be faked in a static prototype, and Round 1 had shown that is exactly where the remaining unknowns lived. I built it in React and deployed it.',
      bold: ['I argued against it', 'is exactly where the remaining unknowns lived'],
    },
    specs: [
      { v: '30', l: 'hi-fi screens' },
      { v: '12s', l: 'real per-question timer', hot: true },
      { v: '22', l: 'recorded sessions, round 1' },
      { v: 'First', l: 'usability test in company history' },
    ],
    linkLabel: 'Open the coded prototype',
    linkHref: 'https://fipet-quiz-battle.vercel.app/',
  },

  fullStory: {
    heading: 'The full story',
    paragraphs: [
      {
        title: 'What the interviews actually said',
        body: {
          text: 'I ran 10 interviews in my first week, intercepting parents and kids in coffee shops, parks, and on the street so I could watch kids approach the app while parents read what they were seeing. A formal focus group was not realistic in the time available, and I would run one now. The pattern was unambiguous and it was not about the financial content. Ten of ten described the app as visually overwhelming. One parent compared it to a textbook. Another said it felt like homework, which was the exact frame the product was built to avoid.',
          bold: ['it was not about the financial content'],
        },
      },
      {
        title: 'What Round 2 cost, and what it taught',
        body: {
          text: 'Round 2 launched unmoderated on the live coded build with 7 participants. Every one of them dropped off before finishing, which produced zero reportable data and one expensive lesson: unmoderated tests on external prototypes bleed participants at every context switch, and a portfolio-grade build does not fix a recruitment-grade problem. All four Round 1 refinements remain live in the build, and the open questions now belong to a moderated round. I would rather report that than quietly drop the round from the case.',
          bold: ['zero reportable data and one expensive lesson', 'I would rather report that'],
        },
      },
    ],
  },

  reflections: [
    { num: '01', title: 'Introducing testing changed more than any screen',
      body: 'Once everyone had a shared evidence base, the PM stopped defending preferences with intuition and engineers stopped pushing back with their own assumptions. The arguments got smaller and the work got faster.' },
    { num: '02', title: 'A design system is judged by adoption, not coverage',
      body: 'Four decisions, not forty, plus a short documentation set. Other designers used it for screens I never touched. A complete system nobody uses is worse than a smaller one that ships.' },
  ],

  footer: {
    copyright: '© 2026 Dean Yoo',
    links: [
      { label: 'Email', href: 'mailto:hyart2021@gmail.com' },
      { label: 'LinkedIn', href: 'https://linkedin.com/in/dean-yoo' },
      { label: 'Resume', href: '/resume' },
    ],
  },
}

// ═══════════════════════════════════════════════════════

export const lyftCaseV2: CaseV2 = {
  card: {
    slug: 'ride-availability',
    tags: ['Product design', 'Research'],
    title: 'Lyft Bike Redesign',
    description: 'Lyft has the prediction algorithms, real-time monitoring, and incentive programs already built. None of it reaches riders. I designed the UX layer that puts it in front of them.',
    year: '2026',
    category: 'Concept · Mobile',
    featured: true,
    order: 3,
    coverImage: '/images/lyft-cover.webp',
    thumbBg: '#1a1a2e',
  },
  meta: 'Mar – May 2026 · Self-directed concept',
  h1: ['Lyft can predict the dock.', 'Riders never see it.'],
  heroImage: '/images/lyft-hero-v2.webp',
  heroAlt: 'Lyft bike ride flow with dock availability prediction at station selection',
  heroOverlays: [],

  roleMeta: [
    { label: 'Role',  value: 'Solo designer, end to end' },
    { label: 'Scope', value: 'Research, journey mapping, interaction design, testing' },
    { label: 'Tools', value: 'Figma, Maze' },
  ],

  statCard: {
    text: 'I checked availability at home, rode 15 minutes, and found every dock taken. Then it happened again the next week.',
    bold: 'found every dock taken',
  },

  overview: {
    label: 'Overview',
    body: {
      text: 'Lyft already runs AirControl for real-time station monitoring, pays riders through Bike Angels to rebalance the network, and forecasts dock availability internally. None of it reaches the rider. I designed the UX layer that surfaces what already exists, which makes this mostly a frontend lift rather than new technology.',
      bold: ['None of it reaches the rider', 'mostly a frontend lift rather than new technology'],
    },
    linkLabel: 'Open the prototype',
    linkHref: 'https://www.figma.com/proto/iE519vGwIttO6MSAx6sTxd/Lyft-redesign-testing?node-id=0-662&starting-point-node-id=0%3A662&page-id=0%3A1',
  },

  outcome: {
    label: 'Outcome',
    body: {
      text: 'Round 1 validated the dock prediction direction, pushed back on the pricing hypothesis, and produced three specific fixes for Round 2. The project is ongoing and the numbers below are honest about their sample sizes.',
      bold: ['pushed back on the pricing hypothesis'],
    },
    results: [
      { value: 4.4, decimals: 1, suffix: '/5', label: 'dock confidence', hot: true,
        desc: 'How confident participants felt they would find an available dock at the destination. n = 10.' },
      { value: 100, suffix: '%', label: 'dock planning success',
        desc: 'Every recorded session completed the dock planning flow. 10 sessions.' },
      { value: 45, suffix: '%', label: 'misclick rate',
        desc: 'Everyone eventually succeeded, which is exactly how an affordance failure hides inside a passing funnel.' },
    ],
  },

  persona: {
    label: 'Who it is for',
    name: 'Sarah Kim',
    meta: 'Age 29 · daily commuter',
    quote: '“If I can’t rely on it every morning, I’ll just take the train.”',
    needs: [
      'A dock she can count on being open at arrival',
      'Reliability she can build a schedule around',
      'Recovery options that do not burn commute time',
    ],
    implication: 'Two more rider contexts shaped the work, a multi-modal navigator and a weekend explorer. All three converge on the same need at station selection and differ only in how they weigh price against time against certainty.',
  },

  journey: {
    label: 'Journey',
    statement: 'Every dock decision has to happen before the bike unlocks.',
    body: {
      text: 'This is a safety constraint, not a design preference. Once the rider is moving, asking them to compare stations means asking them to use a phone while cycling. That single rule decided where every feature could live.',
      bold: ['a safety constraint, not a design preference'],
    },
    moments: [
      {
        phase: 'Before unlocking',
        question: 'Will there be a dock when I get there?',
        surface: 'Station selection, three route options',
        breaks: 'Without prediction here, every ride is a bet placed on incomplete information.',
      },
      {
        phase: 'Mid-ride',
        question: 'Is the plan still good?',
        surface: 'iOS Live Activity, Dynamic Island',
        breaks: 'Any interface that invites a tap here is a safety problem. Glance-only or nothing.',
      },
      {
        phase: 'On arrival',
        question: 'What if the prediction was wrong?',
        surface: 'Reroute and $1.00 credit',
        breaks: 'A rider burned once will not trust the prediction again unless the system owns the mistake.',
      },
    ],
  },

  evidence: {
    label: 'Evidence',
    statement: 'The display meant two different things to two halves of the room.',
    body: {
      text: 'Half the participants read the predicted-versus-actual dock count correctly. The other half did not: one took it as walking-speed variance, another as the number of riders currently unlocking bikes. A comprehension split is worse than a low score, because trust requires everyone reading the same thing the same way.',
      bold: ['A comprehension split is worse than a low score'],
    },
  },

  research: {
    label: 'Research',
    statement: 'Existing internal tools are a tell.',
    body: {
      text: 'AirControl and Bike Angels exist because the rider-facing product could not steer the network, so the network had to be managed from outside it. When a company builds tooling that operates around its primary product, the primary product usually has a gap. That question, what is the operations team using that the product cannot do, is the one I now ask at the start of a project.',
      bold: ['the primary product usually has a gap'],
    },
  },

  solution1: {
    label: 'Solution 01',
    statement: 'The incentive lives inside a number riders already compare',
    body: {
      text: 'Per-minute rate moves with station supply. Overstocked stations price lower to clear bikes, understocked stations price higher to protect what is left. No badge, no banner, no new UI to learn.',
      bold: ['No badge, no banner, no new UI to learn'],
    },
    bento: {
      a: {
        tag: 'At the station',
        level: 'Overstocked',
        pct: '$0.39/min',
        sentence: 'Riders already compare price and time. Putting the nudge inside that comparison means no new behavior has to be adopted.',
        whyTag: 'Three tiers',
        rows: [
          ['Overstock', '75% or more bikes · $0.39/min'],
          ['Normal', '25 to 74% · $0.44/min'],
          ['Understock', 'under 25% · $0.49/min'],
        ],
      },
      b: {
        tag: 'Before the ride',
        title: 'Dock prediction on every route option',
        pills: [
          { label: 'Fastest', active: false },
          { label: 'Cheapest', active: true },
          { label: 'Closest', active: false },
        ],
        sliderPct: 80,
        note: 'Very likely, likely, or limited availability at the arrival station. All three options comparable in one glance.',
      },
      c: {
        tag: 'When it fails',
        ticketTitle: 'Dock filled before arrival',
        ticketMeta: 'Live Activity · reroute issued',
        lockLabel: '$1.00 credit, automatic',
        rightTitle: 'No app to open',
        rightSub: 'glance-only by design',
        caption: 'The system owns the mistake, or the rider stops believing the prediction.',
      },
    },
  },

  exploration: {
    label: 'Exploration',
    statement: 'Two ways to surface the incentive that would have been ignored',
    body: {
      text: 'Badges add a fifth element to a screen already carrying three options plus time and distance. Banners get dismissed. Neither changes behavior, which is the only thing that matters here.',
      bold: ['Neither changes behavior'],
    },
    alternatives: [
      {
        verdict: '✗',
        title: 'Explicit incentive badges',
        what: 'Save $0.30 badges layered onto each dock option at route selection.',
        why: 'A fifth visual element on a screen already carrying three options plus time and distance. Riders have been trained by every other app to tune financial badges out.',
      },
      {
        verdict: '✗',
        title: 'Passive banner notifications',
        what: 'Earn $0.50 credit for starting here, surfaced as a dismissible banner near station selection.',
        why: 'Cheap to build and easy to ignore. It reads as an ad rather than a system message, and it sits outside the price-versus-time comparison riders are already making.',
      },
      {
        verdict: '✓',
        title: 'Dynamic pricing in the existing UI',
        what: 'The per-minute rate moves with station supply. No badge, no banner, no new element.',
        why: 'The incentive lives inside a number riders already compare, so there is no new UI to learn and no new behavior to adopt. Departure-side pricing research reports +300% revenue and 76% lower rebalancing cost against fixed pricing.',
      },
    ],
  },

  underHood: {
    label: 'Under the hood',
    statement: 'Every feature maps to something Lyft already runs',
    body: {
      text: 'AirControl supplies real-time station state. Bike Angels already proves riders will rebalance for an incentive, with top users earning $3K a month. The Live Activities API delivers passive mid-ride alerts. Internal demand prediction supplies the forecasts. The contribution is the UX layer, not the technology.',
      bold: ['The contribution is the UX layer, not the technology'],
    },
    specs: [
      { v: 'Zero', l: 'new technology required', hot: true },
      { v: '+300%', l: 'revenue vs fixed pricing, PMC 2025' },
      { v: '−76%', l: 'rebalancing cost, same study' },
      { v: '$1.00', l: 'credit when prediction fails' },
    ],
    linkLabel: 'Open the prototype',
    linkHref: 'https://www.figma.com/proto/iE519vGwIttO6MSAx6sTxd/Lyft-redesign-testing?node-id=0-662&starting-point-node-id=0%3A662&page-id=0%3A1',
  },

  fullStory: {
    heading: 'The full story',
    paragraphs: [
      {
        title: 'Why departure-side pricing, not destination-side',
        body: {
          text: 'The intuitive answer is to charge more for docking at understocked stations so riders go where the bikes are needed. I rejected it. Destination-side pricing puts the financial decision at the wrong moment, when the rider has already committed and the bike is already moving. Asking someone to reroute mid-ride to save thirty cents is exactly the phone use the safety constraint rules out. Departure-side pricing handles both halves of the imbalance at the start: it clears bikes from overstocked stations and frees the full docks at the same time.',
          bold: ['puts the financial decision at the wrong moment'],
        },
      },
      {
        title: 'What Round 1 settled, and what it did not',
        body: {
          text: 'Maze counts sessions rather than unique people, so response counts vary by block: 10 sessions on the dock planning flow, 8 on station comparison, 5 to 10 on the opinion scales. That is enough to expose a broken affordance and not enough to claim an effect. Round 2 is scoped against concrete targets rather than a vague improvement: misclick under 25%, prediction comprehension above 80%, dock confidence held at 4.4 or higher. The pricing hypothesis did not hold in Round 1, and riders optimized for speed and proximity instead.',
          bold: ['not enough to claim an effect', 'The pricing hypothesis did not hold'],
        },
      },
    ],
  },

  reflections: [
    { num: '01', title: 'Reframing the brief was the design decision',
      body: 'Moving from add dock info to surface existing infrastructure changed what I was solving for, how success would be measured, and which directions were worth exploring at all. Two obvious approaches died the moment the brief shifted.' },
    { num: '02', title: 'Frustration becomes research only when you treat it as data',
      body: 'Getting burned by a full dock is an anecdote. It turned into a brief when I started logging it, mapping the journey, and looking for the systemic cause instead of riding around the problem.' },
  ],

  footer: {
    copyright: '© 2026 Dean Yoo',
    links: [
      { label: 'Email', href: 'mailto:hyart2021@gmail.com' },
      { label: 'LinkedIn', href: 'https://linkedin.com/in/dean-yoo' },
      { label: 'Resume', href: '/resume' },
    ],
  },
}

// ═══════════════════════════════════════════════════════

export const biaslyCaseV2: CaseV2 = {
  card: {
    slug: 'biasly',
    tags: ['Product design', 'Mobile'],
    title: 'Biasly Mobile App',
    description: 'Biasly helps users understand political bias before engaging with content. The feed made that context easy to miss.',
    year: '2025',
    category: 'Internship · Mobile',
    featured: true,
    order: 4,
    coverImage: '/images/biasly-cover.webp',
    thumbBg: '#1c2340',
  },
  meta: 'Oct – Dec 2025 · Internship',
  h1: ['They read the headline first.', 'The bias came too late.'],
  heroImage: '/images/biasly-hero-v2.webp',
  heroAlt: 'Biasly feed card with bias spectrum anchored above the headline',
  heroOverlays: [],

  roleMeta: [
    { label: 'Role',  value: 'Product design intern' },
    { label: 'Team',  value: 'PM, 2 engineers' },
    { label: 'Tools', value: 'Figma, Maze, Notion' },
  ],

  statCard: {
    text: '69% of participants could not identify the bias of articles they had just spent time reading. Almost all of them said the same thing: they never noticed it.',
    bold: '69% of participants',
  },

  overview: {
    label: 'Overview',
    body: {
      text: 'Biasly exists to show political bias before you engage with a story. The indicator was there, at the bottom of every card, arriving after the reader had already formed an opinion. I moved it above the headline and replaced the text label with a spectrum that reads at scroll speed.',
      bold: ['arriving after the reader had already formed an opinion'],
    },
    linkLabel: 'See the shipped feed',
    linkHref: 'https://dean-yoo.com/work/biasly',
  },

  outcome: {
    label: 'Outcome',
    body: {
      text: 'Post-redesign sessions used the same participants, the same task, and the same duration. One variable changed: the layout.',
      bold: ['One variable changed: the layout.'],
    },
    results: [
      { value: 78, suffix: '%', label: 'bias recognition', hot: true,
        desc: 'Up from 31% on an identical task with an identical group. n = 12.' },
      { value: 3, suffix: '×', label: 'faster recognition',
        desc: 'Median time to identify bias fell from 9 seconds to 3.' },
      { value: 60, suffix: '%', label: 'drop in missed indicators',
        desc: 'Observer-coded instances of bias data being overlooked entirely.' },
    ],
  },

  persona: {
    label: 'Who it is for',
    name: 'A politically aware reader',
    meta: '12 moderated sessions · ages 22 to 45',
    quote: '“I usually just read the headline. I didn’t even see the bias tag.”',
    needs: [
      'A fast read on the day, not an evaluation exercise',
      'Context that arrives before the first impression forms',
      'A signal that survives fast scrolling',
    ],
    implication: 'The anti-persona matters here. A reader who has already decided which sources to trust has no interest in being challenged, and the redesign is deliberately not for them.',
  },

  journey: {
    label: 'Journey',
    statement: 'The problem was not visibility. It was sequence.',
    body: {
      text: 'Think-aloud sessions produced the same path in every participant: headline, image, scroll. The bias tag was processed last, when it was processed at all. Nobody voluntarily scrolled back up to check bias after forming an impression.',
      bold: ['headline, image, scroll', 'Nobody voluntarily scrolled back up'],
    },
    moments: [
      {
        phase: 'Card enters view',
        question: 'Is this worth my attention?',
        surface: 'Card header, source name',
        breaks: '100% of participants began scanning here. Anything that is not here is arriving late.',
      },
      {
        phase: 'Headline read',
        question: 'What do I think about this?',
        surface: 'Headline',
        breaks: 'The opinion forms in this instant. Context delivered afterward is a correction, not a frame.',
      },
      {
        phase: 'Scroll past',
        question: 'Next.',
        surface: 'Bias tag, original position',
        breaks: 'The indicator lived here, and it was the last element registered or not registered at all.',
      },
    ],
  },

  evidence: {
    label: 'Evidence',
    statement: 'An overlay was dismissed as an ad within one second, every time.',
    body: {
      text: 'I tested a floating badge that appeared when the reader paused on a card. Every session dismissed it inside a second. Readers have been trained by a decade of the web to ignore anything that floats on top of content. Structural position cannot be trained away the same way, and that finding ended the overlay direction after three sessions.',
      bold: ['Every session dismissed it inside a second', 'Structural position cannot be trained away'],
    },
  },

  research: {
    label: 'Research',
    statement: 'The most useful finding came from users I was not designing for.',
    body: {
      text: 'Two politically engaged participants said the upfront label was distracting on topics where they already held a firm view. They wanted to judge the headline before knowing the source’s leaning. That forced a real decision with the PM about who the product is for, and the answer was readers becoming more aware rather than readers who already are. The header position stayed, and the finding rewrote the onboarding copy instead.',
      bold: ['who the product is for'],
    },
  },

  solution1: {
    label: 'Solution 01',
    statement: 'Bias arrives before the headline, encoded rather than written',
    body: {
      text: 'The pill moved to the card header, next to the source name, first in every scan sequence. The text label became a left-to-right spectrum, so direction and intensity register together without reading.',
      bold: ['first in every scan sequence'],
    },
    bento: {
      a: {
        tag: 'In the header',
        level: 'Before the headline',
        pct: '100%',
        sentence: 'Every participant began scanning at the top of the card, which makes the header the only position that cannot be skipped.',
        whyTag: 'What the spectrum encodes',
        rows: [
          ['Left', 'blue'],
          ['Center', 'purple'],
          ['Right', 'red'],
        ],
      },
      b: {
        tag: 'In the hierarchy',
        title: 'Images cut from banners to thumbnails',
        pills: [
          { label: 'Full-width banner', active: false },
          { label: 'Constrained thumbnail', active: true },
        ],
        sliderPct: 40,
        note: 'Not an aesthetic call. It was the only way to give bias enough visual weight to compete with a large image.',
      },
      c: {
        tag: 'Across surfaces',
        ticketTitle: 'Same encoding in the article view',
        ticketMeta: 'feed · article · detail',
        lockLabel: 'One system to learn',
        rightTitle: 'No re-interpretation',
        rightSub: 'learned once, read everywhere',
        caption: 'A code that changes between screens is not a code.',
      },
    },
  },

  exploration: {
    label: 'Exploration',
    statement: 'Three ways to surface bias earlier',
    body: {
      text: 'Each traded visibility against disruption differently. Two of them left the sequence problem untouched, which is to say they moved the label without moving the moment.',
      bold: ['they moved the label without moving the moment'],
    },
    alternatives: [
      {
        verdict: '✗',
        title: 'Floating overlay on scroll pause',
        what: 'A bias badge appears over the image when the reader pauses on a card.',
        why: 'Dismissed as an ad within one second in every test session. It also only appears on a pause, so anyone scrolling at constant speed never sees it at all.',
      },
      {
        verdict: '✗',
        title: 'Bias bar below the headline',
        what: 'A thin color bar replaces the text label, sitting between the headline and the body text.',
        why: 'The visual encoding is an improvement and the position is not. It is still below the headline, so the impression has already formed by the time it is read.',
      },
      {
        verdict: '✓',
        title: 'Anchored to the card header',
        what: 'Pill and spectrum move above the headline, next to the source name.',
        why: 'First in every scan sequence, and it cannot be skipped without being seen. A fixed position across every card also builds pattern recognition, which a conditional overlay never can.',
      },
    ],
  },

  fullStory: {
    heading: 'The full story',
    paragraphs: [
      {
        title: 'What a structural change actually costs',
        body: {
          text: 'Moving an indicator from the bottom of a card to the top sounds small. In practice it meant renegotiating the entire visual hierarchy, which affected image treatment, source name positioning, and the overall balance of the card. Every stakeholder I showed it to reacted to the image reduction before they noticed the bias placement. Advocating for a structural change means being prepared to defend every downstream consequence of it, and most of the conversation was about the consequences rather than the change.',
          bold: ['being prepared to defend every downstream consequence'],
        },
      },
      {
        title: 'What I would verify before claiming more',
        body: {
          text: 'The sessions measured recognition accuracy in a controlled task. They cannot tell me whether reading behavior changed over weeks, whether people click into opposing sources more often, or whether the indicator does its job outside a moderated room. The spectrum also assumes blue reads as left and red as right, which is an American convention and a relatively recent one. A single annotated card on first use would calibrate that, and testing whether it raises first-session accuracy is the next study I would run.',
          bold: ['They cannot tell me whether reading behavior changed over weeks', 'an American convention'],
        },
      },
    ],
  },

  reflections: [
    { num: '01', title: 'The disconfirming finding was the valuable one',
      body: 'Feedback from politically engaged users who found the upfront label distracting was more useful than the data that agreed with me. It clarified who the product is for and changed decisions beyond the feed.' },
    { num: '02', title: 'Sequence is a design material',
      body: 'The indicator was always visible. It was never early. Changing when something appears turned out to be a larger intervention than changing how it looks.' },
  ],

  footer: {
    copyright: '© 2026 Dean Yoo',
    links: [
      { label: 'Email', href: 'mailto:hyart2021@gmail.com' },
      { label: 'LinkedIn', href: 'https://linkedin.com/in/dean-yoo' },
      { label: 'Resume', href: '/resume' },
    ],
  },
}

// ═══════════════════════════════════════════════════════
//  slug -> 케이스 레지스트리.
//  app/work/[slug]/page.tsx 가 이걸로 어느 케이스를 그릴지 고른다.
//  slug 는 기존 projects[] 의 slug 와 정확히 같아야 한다.
// ═══════════════════════════════════════════════════════

export const casesV2: Record<string, CaseV2> = {
  'triage': siftCaseV2,
  'fipet': fipetCaseV2,
  'ride-availability': lyftCaseV2,
  'biasly': biaslyCaseV2,
}

export function getCaseV2(slug: string): CaseV2 | null {
  return casesV2[slug] ?? null
}

export const caseV2Slugs = Object.keys(casesV2)


// ═══════════════════════════════════════════════════════
//  홈 목록용 헬퍼.
//  카드 정보는 각 케이스의 card 블록 하나에서만 나온다.
//  예전 projects[] 와 60개짜리 Project 타입은 삭제했다.
// ═══════════════════════════════════════════════════════

export type Project = CaseCard

export const projects: CaseCard[] = Object.values(casesV2).map((c) => c.card)

export function getProject(slug: string): CaseCard | null {
  return projects.find((p) => p.slug === slug) ?? null
}

export function getFeatured(): CaseCard[] {
  return projects.filter((p) => p.featured).sort((a, b) => a.order - b.order)
}

export function getAllSorted(): CaseCard[] {
  return [...projects].sort((a, b) => a.order - b.order)
}
